#include "Arduino.h"
#ifndef SIMPLIFY_H
#define SIMPLIFY_H

class Simplify {
	public:
		Simplify(int trigPin, int echoPin);
		long GetDistance();
		long microsecondstocm(long duration);
	private:
		int _trigPin;
		int _echoPin;
};
#endif