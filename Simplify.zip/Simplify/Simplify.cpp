//c++ code
#include "Arduino.h"
#include "Simplify.h"
Simplify::Simplify(int trigPin, int echoPin)
{
    _trigPin = trigPin;
    _echoPin = echoPin;
    pinMode(_trigPin, OUTPUT);
    pinMode(_echoPin, INPUT);
}
long Simplify::GetDistance()
{
    digitalWrite(_trigPin, LOW);
    delayMicroseconds(2);
    digitalWrite(_trigPin, HIGH);
    delayMicroseconds(10);
    digitalWrite(_trigPin, LOW);
    long duration = pulseIn(_echoPin, HIGH);
    if (duration == 0)
    {
        return 0;
    }
    return microsecondstocm(duration);
}
long Simplify::microsecondstocm(long microseconds)
{
    return microseconds / 29 / 2;
}